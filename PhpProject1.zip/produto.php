<?php

include 'class/ProdutoControle.class.php';

$produto = new Produto();
$produto->setId($_GET['id']);

$pc = new ProdutoControle();

$produto = $pc->listaUm($produto);

?>
<center>
    <table border="2">
        <tr>
            <td><h1><center><?php echo $produto->getNome(); ?></center></h1></td>
        </tr>
        <tr>
            <td width="300px" height="300px"></td>
        </tr
        <tr>
            <td><center>R$ <?php echo $produto->getPreco(); ?></center></td>
        </tr>
        <tr>
            <td><center><?php echo $produto->getDescricao(); ?></center></td>
        </tr>

    </table>
</center>
