<?php

include 'class/AdministradorUsuarioControle.class.php';
include 'class/CategoriaControle.class.php';


$ac = new AdministradorUsuarioControle();


var_dump($ac->listaTodos());


$produto = new Produto();
$produto->setNome('Leite Quente');
$produto->setPreco(1.99);

$categoria = new Categoria();
$categoria->setId('1');

$produto->setCategoria($categoria);

$pc = new ProdutoControle();
echo $pc->inserir($produto);