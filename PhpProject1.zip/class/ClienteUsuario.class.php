<?php

require 'Usuario.class.php';

class ClienteUsuario extends Usuario{
    
}