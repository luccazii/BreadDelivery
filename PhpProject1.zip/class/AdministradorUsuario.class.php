<?php

require 'Usuario.class.php';

class AdminstradorUsuario extends Usuario{
    
}