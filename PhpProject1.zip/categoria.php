<?php
session_start();

include 'class/CategoriaControle.class.php';

$categoria = new Categoria();
$categoria->setId($_GET['id']);

?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Listar todos as categorias</h1>
        <table border="3" width="100%">
            <tr>
                <th>ID</th>
                <th>Categoria</th>
            </tr>
        <?php
            $cc = new CategoriaControle();
            
            foreach($cc->listaProdutos($categoria) as $c){
                $id = $c->getId();
                $nome = $c->getNome();
                ?>
                <tr onclick="location.href = 'produto.php?id=<?php echo $id; ?>'">
                <?php
                echo "  <th>$id</th>";
                echo "  <th>$nome</th>";
                echo "</tr>";
            }
        ?>
        </table>
    </body>
</html>
